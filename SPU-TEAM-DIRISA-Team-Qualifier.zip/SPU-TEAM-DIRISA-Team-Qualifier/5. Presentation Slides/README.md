# Deliverable 5: Presentation Slides & Technical Documentation

This folder contains presentation materials summarizing our approach, empirical results, and strategic recommendations:

1. **`KZN_Ward_Voter_Turnout_Predictor.pptx`:** Official PowerPoint presentation slide deck summarizing:
   - Problem Context & Provincial Abstention Crisis
   - Data Harmonization & Boundary Crosswalk Methodology
   - Model Benchmark Results (+8.99% MAE gain)
   - The Reportable Negative Finding (Ecological Fallacy)
   - 2026 Turnout Projections (921 Wards) & Policy Recommendations
2. **`Dirisa_Technical_Document.pdf`:** Comprehensive technical qualification document.
3. **`Technical_Specification_Report.md`:** Rubric-aligned architectural document, scientific data limitation matrix, and deployment specification.
