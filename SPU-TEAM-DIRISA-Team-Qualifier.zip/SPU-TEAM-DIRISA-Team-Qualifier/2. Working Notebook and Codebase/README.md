# Deliverable 2: Working Notebook and Codebase

This folder contains the complete, autonomous data science pipeline from data collection through model output.

### Key Assets:
- **`full_pipeline.ipynb`:** Single, self-contained master Jupyter notebook (64 cells, exit code 0) executing:
  1. Live Web Scraping (Afrobarometer, Ipsos, HSRC eThekwini)
  2. IEC ASP.NET WebForms ward registration scraping (44 municipalities)
  3. Comprehensive 4-check data cleansing engine (73 raw files)
  4. MDB Voting District boundary harmonization (4,940 VDs -> 901 reference wards)
  5. Leakage-free feature engineering and 6 analytical visualizations
  6. Model training: Naive Baseline vs. Winning Random Forest vs. Negative Finding
  7. 2026 ward-level turnout forecasts (921 wards)
  8. Production deployment schema contract
- **`data/`:** The two canonical master datasets (`ward_historical_training_panel_2000_2021.csv` and `ward_2026_prediction_application.csv`).
- **`dashboard/app.py`:** Fully deployed interactive Streamlit decision-support platform.
