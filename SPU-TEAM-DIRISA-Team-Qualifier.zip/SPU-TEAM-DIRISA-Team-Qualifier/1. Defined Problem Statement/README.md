# Deliverable 1: Defined Problem Statement

### Theme: Civic Participation and Voter Turnout in KwaZulu-Natal (2000–2026)

**Core Research Question:**
> *Which wards in KwaZulu-Natal are at greatest risk of low voter turnout in the 2026 Local Government Elections, and which historical, geographic, and socioeconomic indicators are associated with that risk?*

**Why It Matters:**
- Turnout in KZN municipal elections collapsed from **59.8% in 2000** to an alarming **49.5% in 2021**, with over 300 wards below 40%.
- Identifies two distinct non-voting groups: the **Turnout Gap** (2.4M registered citizens who abstain) and the **Registration Gap** (2.1M eligible unregistered youth).
- Directly empowers the Electoral Commission of South Africa (IEC), local government planners, and civic organizations to allocate voter education resources with ward-level precision.

**Included Deliverables in this folder:**
1. `KZN_Problem_Statement_DIRISA_SDC.pdf` - Full strategic grounding document.
2. `Problem_and_Solution_Statement.md` - Problem statement foundation and civic participation policy rationale.
